const express = require("express");
const adminController = require("../controller/adminController");
const multer = require("multer");

const route = express.Router();

// CONFIG
const storage = multer.memoryStorage();
const file = multer({ storage });

//Uploading multiple house images
const files = file.array([{ name: 'frontPicture', maxCount: 1 }, { name: 'video', maxCount: 1 }, {name: 'bedroom', maxCount: 1}, {name: 'backPicture', maxCount: 1}, {name: 'insidePictureOne', maxCount: 1}]);

// LOGIN CHECKER
const loginChecker = (req, res, next) => {
    if (req.session.user) {
        // user = req.session.user;
        next();
    } else {
        res.redirect("/login");
    }
}

// ROUTES
route.get("/", loginChecker, adminController.home);

// PROFILE
route.get("/profile/:id", loginChecker, adminController.profile);

// PROFILE UPDATE LOGIC
route.put("/profile/:id", loginChecker, adminController.profileUpdate);

// HOUSES

// ADMINS
route.get("/admins", loginChecker, adminController.admins);

// VIEW USER INFORMATION
route.get("/admin/:id", loginChecker, adminController.viewAdmin);

// UPDATE USER INFORMATION
route.put("/admin/edit/:id", adminController.updateAdmin);

// REGISTRATION
route.get("/registration", adminController.registration);

// REGISTRATION LOGIC
route.post("/registration", adminController.registrationLogic);

// DELETE USER (ADMIN)
route.delete("/admin/:id", loginChecker, adminController.deleteAdmin);
// END OF ADMIN

// ADMINS
route.get("/users", loginChecker, adminController.users);

// DELETE USER (ADMIN)
route.delete("/user/:id", loginChecker, adminController.deleteUser);
// END OF USERS

// AGENTS
// GET ALL AGENTS
route.get("/agents", loginChecker, adminController.agents);

// DELETE AGENT
route.delete("/agent/:id", loginChecker, adminController.deleteAgent);
// END OF AGENTS SECTION

// OWNERS
// GET ALL OWNERS
route.get("/owners", loginChecker, adminController.owners);

// DELETE OWNERS
route.delete("/owner/:id", loginChecker, adminController.deleteOwner);
// END OF OWNERS SECTION

// PROPERTY TYPE
route.get("/property-types", loginChecker, adminController.propertyTypes);

// PROPERTY TYPE FORM
route.get("/property-type/add", loginChecker, adminController.addPropertyType);

// PROPERTY TYPE FORM LOGIC
route.post("/property-type/add", adminController.addPropertyTypeLogic);

// VIEW PROPERTY TYPE
route.get("/property-type/:id", adminController.viewPropertyType);

// UPDATE PROPERTY TYPE LOGIC
route.put("/property-type/:id", adminController.updatePropertyType);

// DELETE PROPERTY TYPE
route.delete("/property-type/:id", adminController.deletePropertyType);
// END OF PROPERTY TYPE

// AREAS
route.get("/areas", loginChecker, adminController.areas);

// AREA TYPE FORM
route.get("/area/add", loginChecker, adminController.addArea);

// AREA FORM LOGIC
route.post("/area/add", adminController.addAreaLogic);

// VIEW AREA
route.get("/area/:id", loginChecker, adminController.viewArea);

// UPDATE AREA LOGIC
route.put("/area/:id", adminController.updateArea);

// DELETE AREA
route.delete("/area/:id", adminController.deleteArea);
// END OF AREA

// HOUSE SECTION
// GET ALL HOUSES
route.get("/houses", loginChecker, adminController.houses);

// ADD HOUSE FORM
route.get("/house/add", loginChecker, adminController.addHouse);

// ADD HOUSE FORM LOGIC
route.post("/house/add", file.fields([{ name: 'frontPicture', maxCount: 1 }, { name: 'video', maxCount: 1 }, {name: 'bedroom', maxCount: 1}, {name: 'backPicture', maxCount: 1}, {name: 'insidePictureOne', maxCount: 1}]), adminController.addHouseLogic);
// route.post("/house/add", file.single("frontPicture"), adminController.addHouseLogic); 

// VIEW SINGLE HOUSE
route.get("/house/:id", loginChecker, adminController.viewHouse);

// UPDATE SINGLE HOUSE
route.put("/house/:id", file.fields([{ name: 'frontPicture', maxCount: 1 }, { name: 'video', maxCount: 1 }, {name: 'bedroom', maxCount: 1}, {name: 'backPicture', maxCount: 1}, {name: 'insidePictureOne', maxCount: 1}]), adminController.updateHouseLogic);

// DELETE SINGLE HOUSE
route.delete("/house/:id", loginChecker, adminController.deleteHouse);
// END OF HOUSE SECTION

// ENQUIRIES SECTION
// GET ALL ENQUIRIES
route.get("/enquiries", loginChecker, adminController.enquiries);

// VIEW SINGLE ENQUIRY
route.get("/enquiry/:id", loginChecker, adminController.singleEnquiry);

// UPDATE ENQUIRY LOGIC
route.put("/enquiry/:id", adminController.updateEnquiryLogic);

// DELETE ENQUIRY
route.delete("/enquiry/:id", adminController.deleteEnquiry);

// END OF ENQUIRIES SECTION

// LOGOUT
route.get("/logout", loginChecker, adminController.logout);

// CHATS SECTION
// GET ALL USERS FOR CHATTING
route.get("/chats", loginChecker, adminController.chats);

// GET USER DETAILS
route.get("/chat/:id", loginChecker, adminController.chatUserDetails);

// CHAT LIST
route.get("/chat/add/:receiversID", loginChecker, adminController.chatPage);

// START CHATTING PAGE LOGIC
route.post("/chat/add/:receiversID/:sendersID", adminController.addChat);
// END OF CHATS SECTION

// PAYMENTS SECTION
// GET ALL PAYMENTS
route.get("/tenants", loginChecker, adminController.payments);

// UPDATE PAYMENT
route.put("/payment/:id", adminController.updatePayment);

// VIEW SINGLE PAYMENT INFORMATION
// route.get("/payment/:id", adminController.viewPayment);

// END OF PAYMENTS SECTION

// 404
route.get("/*", loginChecker, adminController.error);

module.exports = route;
