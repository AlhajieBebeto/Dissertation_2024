const express = require('express');
const indexController = require("../controller/indexController");

const route = express.Router();

// LOGIN CHECKER
const loginChecker = (req, res, next) => {
    req.flash("success", "You must be logged in");
    if (req.session.user && req.session.user.type === "User") {
        // user = req.session.user;
        next();
    } else {
        req.flash("error", "You must be a user to view house information");
        res.redirect("/login");
    }
}

// ROUTES
route.get("/", indexController.homepage);

// ABOUT
route.get("/about", indexController.about);

// PROPERTIES
route.get("/properties", indexController.properties);

// PROPERTY
route.get("/property/:id", indexController.singleProperty);

// ENQUIRY
route.post("/enquiry/:id", indexController.addEnquiry);

// LOGIN
route.get("/login", indexController.login);

// LOGIN LOGIC
route.post("/login", indexController.loginlogic);

// SIGN UP
route.get("/signup", indexController.signup);

// SIGN UP LOGIC
route.post("/signup", indexController.signupLogic);

// CONTACT
route.get("/contact", indexController.contact);

// CONTACT FORM LOGIC
route.post("/contact", indexController.contactLogic);

// PAYMENT FORM
route.get("/payment/:id", loginChecker, indexController.payment);

// PAYMENT FORM LOGIC
route.put("/payment/:id", indexController.paymentLogic);

// LOGOUT
route.get("/logout", indexController.logout);

// PAYMENT SUCCESSFUL
route.get("/success", indexController.success);

module.exports = route;
