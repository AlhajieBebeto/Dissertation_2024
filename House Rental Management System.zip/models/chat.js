const mongoose = require("mongoose");

const chatSchema = mongoose.Schema({
    senderid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    receiverid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    content: String,
    read_status: String
}, { timestamps: true});

module.exports = mongoose.model("Chat", chatSchema);
