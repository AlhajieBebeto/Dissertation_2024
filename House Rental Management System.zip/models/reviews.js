const mongoose = require("mongoose");

const reviewsSchema = mongoose.Schema({
    property: {
        type: mongoose.Schema.Types.ObjectId,
        ref : "Property"
    },
    message: {
        type: String,
        required: true
    },
    reviewer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    status: {
        type: Boolean, // To approve or not approve a review
    }
}, { timestamps:true });

module.exports = mongoose.model("Reviews", reviewsSchema);
