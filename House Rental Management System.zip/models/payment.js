const mongoose = require("mongoose");

const paymentSchema = mongoose.Schema({
    payer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    house: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "House"
    },
    paymentType: String,
    amount: Number
}, {timestamps : true});
