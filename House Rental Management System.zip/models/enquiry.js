const mongoose = require("mongoose");

const enquirySchema = mongoose.Schema({
    enquirerName: {
        type: String,
        required: true,
    },
    mobileNumber: {
        type: String,
        required: true,
    },
    email: {
        type: String
    },
    house: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "House"
    },
    message: {
        type: String,
        required: true
    },
    status: {
        type: String,
        required: true
    },
    remark: {
        type: String
    }
}, { timestamps: true });

module.exports = mongoose.model("Enquiry", enquirySchema);
