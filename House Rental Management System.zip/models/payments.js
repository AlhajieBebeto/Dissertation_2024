const mongoose = require("mongoose");

const paymentSchema = mongoose.Schema({
    house: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "House"
    },
    payer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    houseOwner: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    type: String,
    nextpayment: Date
}, {timestamps: true});

module.exports = mongoose.model("Payment", paymentSchema);
