const mongoose = require('mongoose');

const houseSchema = new mongoose.Schema({
  name: String, // Name of the property
  address: String, // Address of the property
  type: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "propertyType"
  }, // e.g., Apartment, House, Commercial, etc.
  bedrooms: Number, // Number of bedrooms that the property has
  bathrooms: Number, // Number of bathrooms that the property has
  size: Number, // in square feet
  price: Number, 
  status: String, // e.g., Available, Rented, Sold
  postedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User' // Reference to the Agent model for property owner
  },
  paidBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User' // Reference to the user that paid for the house
  },
  area: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Area" // Referencing the area of the house
  },
  garage: String, // If the house has garage
  selfContain: String, // If the house is self contained
  insideCompound: String, // If the house is inside a compound
  frontPicture: Buffer, // Picture of the house
  frontPictureName: String, // Name of the picture
  bedroom: Buffer, // Picture of the bedroom
  bedroomPictureName: String, // Name of the bedroom picture
  insidePictureOne: Buffer, // Picture of inside the house
  insidePictureOneName: String, // Name of the picture
  insidePictureTwo: Buffer, // Picture of inside the house
  insidePictureTwoName: String, // Name of the picture
  backPicture: Buffer, // Picture of the back of the house
  backPictureName: String, // Name of the picture
  video: Buffer, // Video of the property
  videoName: String, // Name of the video
  description: String// Other fields as needed
}, { timestamps: true });

const Property = mongoose.model('House', houseSchema);

module.exports = Property;
