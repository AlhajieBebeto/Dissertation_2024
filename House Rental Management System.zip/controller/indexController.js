const User = require("../models/user");
const bcrypt = require("bcrypt");
const nodemailer = require("nodemailer");
const House = require("../models/house");
const PropertyType = require("../models/propertyType");
const Enquiry = require("../models/enquiry");
const Area = require("../models/areaType");
const Payment = require("../models/payments");

// CONFIG
require("dotenv").config();
// NODEMAILER
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL,
    pass: process.env.PASSWORD
  }
});

// HOMEPAGE
exports.homepage = (req, res, next) => {
    User.find({ type: "Select Type" })
        .then(exists => {
            User.findByIdAndDelete({ _id: exists._id })
                .then(deleted => { })
                .catch(err => {})
        })
        .catch(err => {
            res.redirect("back");
    })
    House.find({}).sort({createdAt: -1})
        .then(houses => {
            if (houses) {
                PropertyType.find({})
                    .then(propertyType => {
                        Area.find({})
                        .then(areas => {
                            res.render('index', {
                                title: "House Rental Management System | Homepage",
                                page: "Homepage",
                                houses: houses,
                                propertyType : propertyType,
                                areas: areas
                            });
                        })
                })
            } else {
                res.render('index', {
                    title: "Real Estate Management System | Homepage",
                    page: "Homepage"
                });
            }
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        });
} 

// ABOUT
exports.about = (req, res, next) => {
    res.render('about', {
        title: "House Rental Management System | About",
        page: "About"
    });
}

// PROPERTIES
exports.properties = (req, res, next) => {
    House.find({})
        .then(houses => {
            PropertyType.find({})
                .then(propertyType => {
                    res.render('properties', {
                    title: "House Rental Management System | Properties",
                    page: "Properties",
                    houses: houses,
                    propertyType: propertyType
                });      
            })
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
    })
}

// SINGLE PROPERTY
exports.singleProperty = (req, res, next) => {
    House.findById({_id : req.params.id})
        .then(house => {
            PropertyType.find({})
                .then(propertyType => {
                    User.findById({ _id: house.postedBy })
                        .then(houseadder => {
                            Area.find({})
                            .then(areas => {
                                res.render('property', {
                                    title: "House Rental Management System | Homepage",
                                    page: "Single Property",
                                    houseadder: houseadder,
                                    house: house,
                                    propertyType : propertyType,
                                    areas : areas
                                });        
                            })
                    })
            })
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        });
}

// LOGIN
exports.login = (req, res, next) => {
    res.render('login', {
        title: "House Rental Management System | Login",
        page: "Login"
    });
}

// LOGIN LOGIC
exports.loginlogic = (req, res, next) => {
    User.findOne({ email: req.body.email })
        .then((user) => {
            bcrypt.compare(req.body.password, user.password, (err, isMatch) => {
                if (isMatch) {
                    req.session.user = user;
                    if (req.session.user.type !== "Admin") {
                        req.flash("success", `Welcome ${user.type}`);
                        res.redirect("/");
                        // res.render("index", {
                        //     user: req.session.user,
                        //     title: "Homepage",
                        //     page : "Homepage"
                        // });
                    } else {
                        res.redirect("/admin");
                    }
                } else {
                    req.flash("error", "Email/Password does not match");
                    res.redirect("back");
                }
            })
        })
        .catch(err => {
            req.flash("error", "Email Not Found. Register to log in");
            res.redirect("back");
        });
}

// LOGOUT LOGIC
exports.logout = (req, res) => {
    req.session.destroy();
    req.flash("success", "Logged Out Successfully");
    res.redirect("/login");
}

// SIGN UP
exports.signup = (req, res, next) => {
    res.render('signup', {
        title: "House Rental Management System | Sign Up",
        page: "Sign Up"
    });
}

// SIGN UP LOGIC
exports.signupLogic = (req, res, next) => {
    User.findOne({ email: req.body.email })
        .then(exists => {
            if (exists) {
                req.flash("error", "Email Exists");
                res.redirect("back");
            } else {
                bcrypt.genSalt(10, (err, salt) => {
                    bcrypt.hash(req.body.password, salt, (err, hash) => {
                        if (req.body.type === "User" || req.body.type === "Owner" || req.body.type === "Agent") {
                            User.create({
                                firstName: req.body.firstName,
                                lastName: req.body.lastName,
                                email: req.body.email,
                                password: hash,
                                type: req.body.type
                            })
                                .then((user) => {
                                    // SENDING EMAIL AFTER REGISTRATION
                                    const mailOptions = {
                                        from: process.env.EMAIL,
                                        to: req.body.email,
                                        subject: 'Registration Confirmation',
                                        html: `Dear ${req.body.firstName}, <p>
                                        You have been registered successfully as <strong>${req.body.type}</strong> for the House Rental Management System.</p>
                                        
                                        <p>
                                            Your password is: <strong>${req.body.password}</strong>.
                                        </p>
                                        
                                        <p>
                                            You can change this password after accessing your dashboard.
                                        </p>
                                        
                                        <p>
                                            Sincerely, <br />
                                            HRMS Management
                                        </p>`
                                    };
                
                                    transporter.sendMail(mailOptions, (err, info) => {
                                        if (err) {
                                            console.log(err);
                                        } else {
                                            console.log('Email sent:');
                                        }
                                    });
                                });
                            req.flash("success", "Registration Successful");
                            res.redirect("/login");
                        } else {
                            req.flash("error", "Only Owner, Agent, or User Can be registered, please select one of them");
                            res.redirect("back");
                        }
                    })
                })
            }
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        });
}

// ENQUIRY
exports.addEnquiry = (req, res, next) => {
    House.findById({ _id: req.params.id })
        .then(house => {
            Enquiry.create({
                enquirerName: req.body.name,
                mobileNumber: req.body.contact,
                email: req.body.youremail,
                house: house._id,
                message: req.body.message,
                status: "Enquiry",
            }).then(enquiry => {
                // SENDING EMAIL AFTER ENQUIRY
                const mailOptions = {
                    from: process.env.email,
                    to: req.body.email,
                    subject: 'Enquiry Notification',
                    html: `Dear House Owner/Agent,
                    <p>
                    You have an enquiry for the house you <strong>${house.name} - ${house.address}</strong> posted from <br />
                    ${req.body.name} with Contact Number: ${req.body.contact}. The enquiry information is:
                    </p>
                    
                    <p>
                        ${req.body.message}
                    </p>
                    
                    <p>
                        Sincerely, <br />
                        HRMS Management
                    </p>`
                };
            
                transporter.sendMail(mailOptions, (err, info) => {
                    if (err) {
                        console.log(err);
                    } else {
                        // SENDING MAIL TO THE ENQUIRUER
                        const mailOptions2 = {
                        from: process.env.email,
                        to: req.body.youremail,
                        subject: 'Enquiry Notification',
                        html: `Dear ${req.body.name},
                        <p>
                        Thank you for using our portal to enquire about <strong>${house.name} - ${house.address}</strong>.
                        Your enquiry message has already been sent to the agent/owner. <br /> Rest assured, you will be contacted soon.
                        </p>
                        
                        <p>
                            Sincerely, <br />
                            HRMS Management
                        </p>`
                    };
                
                    transporter.sendMail(mailOptions2, (err, info) => {
                        if (err) {
                            console.log(err);
                        } else {
                            req.flash("success", "Enquiry Sent Successfully");
                            res.redirect("back");
                        }
                    });
                    }
                });
            })
        });
}

// CONTACT
exports.contact = (req, res, next) => {
    res.render('contact', {
        title: "House Rental Management System | Contact",
        page: "Contact"
    });
}

// CONTACT FORM LOGIC
exports.contactLogic = (req, res, next) => {
    // SENDING EMAIL
    const mailOptions = {
        from: req.body.email,
        to: process.env.email,
        subject: `Message from Contact Us Form - ${req.body.subject}`,
        html: `
        <p>
        This message was sent by <strong>${req.body.name}</strong>, from the contact us form. The message is: <br />
        ${req.body.message}
        </p>`
    };

    transporter.sendMail(mailOptions, (err, info) => {
        if (err) {
            console.log(err);
        } else {
            // SENDING MAIL TO THE ENQUIRUER
            const mailOptions2 = {
            from: process.env.email,
            to: req.body.email,
            subject: 'Message Received',
            html: `Dear ${req.body.name},
            <p>
            Thank you for using our portal to contact us, your message has been received and we will contact you soon with a reply.
            </p>
            
            <p>
                Sincerely, <br />
                HRMS Management
            </p>`
        };
    
        transporter.sendMail(mailOptions2, (err, info) => {
            if (err) {
                console.log(err);
            } else {
                const back = req.url;
                // res.send("<script>alert('Message Sent')</script>")
                req.flash("success", "Message Sent Successfully");
                res.redirect("back");
            }
        });
        }
    });
}

// PAYMENT FORM
exports.payment = (req, res, next) => {
    House.findById({_id: req.params.id})
    .then(house => {
        res.render("payment", {
            title : "House Rental Management System | Payment Form",
            page: "Payment Form",
            house: house
        });
    })
    .catch(err => {
        console.log(err);
        res.redirect("back");
    })
}

// PAYMENT FORM LOGIC
exports.paymentLogic = (req, res, next) => {
    if(req.body.chargeType === "credit card"){
        House.findByIdAndUpdate({ _id: req.params.id }, {
            status: "Not Available",
            paidBy: req.session.user._id
        })
            .then(house => {
            // SENDING EMAIL TO THE PAYER
            const mailOptions = {
                from: process.env.EMAIL,
                to: req.session.user.email,
                subject: `Payment Successful`,
                html: `
                <p>
                Dear ${req.session.user.firstName} ${req.session.user.lastName}, <br />
                This message is confirmation of your payment of NLE ${house.price} for the house: <strong>${house.name}, situated at ${house.address}</strong>.
                </p>
                <p>
                You can now access your dashboard via the system and chat with either the Admin of the system, or the house owner/agent for any enquiry you may have.
                </p>

                <p>
                    Sincerely, <br />
                    HRMS Management
                </p>
                `
                };
                
                Payment.create({
                house: req.params.id,
                payer: req.session.user._id,
                houseOwner: house.postedBy,
                type : "Credit Card"
                })
                    .then(payment => {
                        console.log("Payment created successfully");
                    })
                    .catch(err => {
                        console.log(err);
                })

            transporter.sendMail(mailOptions, (err, info) => {
                if (err) {
                    console.log(err);
                } else {
                    User.findById({_id : house.postedBy})
                    .then(houseowner => {
                        // SENDING MAIL TO THE AGENT/OWNER
                        const mailOptions2 = {
                        from: process.env.email,
                        to: houseowner.email,
                        subject: 'Payment Made',
                        html: `Dear ${houseowner.firstName} ${houseowner.lastName},
                        <p>
                        This message is to inform you that the house <strong>${house.name}</strong> that you posted on our platform has been paid for by <strong>${req.session.user.firstName} ${req.session.user.lastName}</strong>, at the price of ${house.price}.
                        </p>

                        <p>
                        The sum of NLE ${house.price} will be sent to your account upon confirmation from the customer that the house is now in their care.
                        </p>
                        
                        <p>
                            Sincerely, <br />
                            HRMS Management
                        </p>`
                    };
                
                    transporter.sendMail(mailOptions2, (err, info) => {
                        if (err) {
                            console.log(err);
                        } else {
                            const back = req.url;
                            // res.send("<script>alert('Message Sent')</script>")
                            req.flash("success", "Payment Successful");
                            res.redirect("/success");
                        }
                    });
                    })
                }
            });
        })
        .catch(err => {
            console.log(err);
            req.flash("error", "Payment Unsuccessful")
            res.redirect("back");
        })
    }else if(req.body.chargeType === "by hand"){
        House.findByIdAndUpdate({ _id: req.params.id }, {
            paidBy: req.session.user._id
        })
        .then(house => {
            // SENDING EMAIL TO THE PAYER
            const mailOptions = {
                from: process.env.EMAIL,
                to: req.session.user.email,
                subject: `Payment Successful`,
                html: `
                <p>
                Dear ${req.session.user.firstName} ${req.session.user.lastName}, <br />
                This message is confirmation of your option to pay for the house: <strong>${house.name}, situated at ${house.address}</strong> by ${req.body.paymentType}.
                </p>
                <p>
                You can now access your dashboard via the system and chat with the Admin of the system to indicate when you will bring the ${req.body.paymentType} so that you can have access to the property. You can also chat with the house owner/agent after all payment has been made and confirmed.
                </p>

                <p>
                    Sincerely, <br />
                    HRMS Management
                </p>
                `
            };

            Payment.create({
                house: req.params.id,
                payer: req.session.user._id,
                houseOwner: house.postedBy,
                type : "Credit Card"
                })
                    .then(payment => {
                        console.log("Payment created successfully");
                    })
                    .catch(err => {
                        console.log(err);
                })

            transporter.sendMail(mailOptions, (err, info) => {
                if (err) {
                    console.log(err);
                } else {
                    User.findById({_id : house.postedBy})
                    .then(houseowner => {
                        // SENDING MAIL TO THE AGENT/OWNER
                        const mailOptions2 = {
                        from: process.env.email,
                        to: houseowner.email,
                        subject: 'Payment By Hand',
                        html: `Dear ${houseowner.firstName} ${houseowner.lastName},
                        <p>
                        This message is to inform you that the house <strong>${house.name}</strong> that you posted on our platform has received a payment by hand request, and we will communicate with you when payment would have been made by the customer, so that keys and any other necessary document(s) will be given to the said customer. The house will be paid for at the price of ${house.price}.
                        </p>

                        <p>
                        The sum of NLE ${house.price} will be sent to your account upon confirmation from the customer that the house is now in their care after giving us the money.
                        <br />
                        Also, kindly update the status of the house from Available to Not Available via your dashboard after transaction has been concluded.
                        </p>
                        
                        <p>
                            Sincerely, <br />
                            HRMS Management
                        </p>`
                    };
                
                    transporter.sendMail(mailOptions2, (err, info) => {
                        if (err) {
                            console.log(err);
                        } else {
                            req.flash("success", "Payment option saved. Please talk to an admin via your dashboard");
                            res.redirect("/success");
                        }
                    });
                    })
                }
            });
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        });
    } 
}

// PAYMENT SUCCESS PAGE
exports.success = (req, res, next) => {
    res.render("paymentSuccessful", {
        title : "Payment Successful Page"
    });
}
