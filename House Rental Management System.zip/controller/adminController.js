const nodemailer = require("nodemailer");
const User = require("../models/user");
const PropertyType = require("../models/propertyType");
const House = require("../models/house");
const Area = require("../models/areaType");
const Enquiry = require("../models/enquiry");
const Reviews = require("../models/reviews");
const bcrypt = require("bcrypt");
const Chat = require("../models/chat");
const Payment = require("../models/payments");

// CONFIG
require("dotenv").config();
// NODEMAILER
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL,
    pass: process.env.PASSWORD
  }
}); 

// DASHBOARD
exports.home = (req, res, next) => {
    User.find({}).then(users => {
    if (users) {
        Area.find({}).then(areas => {
        House.find({}).then(houses => {
        PropertyType.find({}).then(propertytypes => {
        Payment.find({}).then(payments => {
            res.render("admin/home", {
                title: "Dashboard",
                users: users,
                areas: areas,
                houses: houses,
                propertytypes: propertytypes,
                payments: payments
            });
        })
            })
            })
            })
    }
    })
        .catch(err => {
            console.log(err);
            res.redirect("back");
    })
}

// PROFILE PAGE
exports.profile = (req, res, next) => {
    User.findById({ _id: req.params.id })
        .then(user => {
            res.render("admin/profile", {
                title: "Profile",
                user:user
            });
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
    })
}

// PROFILE UPDATE LOGIC
exports.profileUpdate = (req, res, next) => {
    if (req.body.password !== "") {
        bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(req.body.password, salt, (err, hash) => {
                User.findByIdAndUpdate({ _id: req.params.id }, {
                    firstName: req.body.firstName,
                    lastName: req.body.lastName,
                    email: req.body.email,
                    password: hash
                })
                    .then((user) => {
                        req.flash("success", "User Information Updated Successfully");
                    })
                    .catch((err) => {
                        req.flash("error", "User Information Not Updated");
                        res.redirect("back");
                    });
            });
        });
    }else {
        User.findByIdAndUpdate({ _id: req.params.id }, {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email
        })
            .then(user => {
                req.flash("User Information Updated Successfully");
                res.redirect("back");
            })
            .catch(err => { });
    }
}

// USERS (ADMIN)
exports.admins = (req, res, next) => {
    User.find({})
        .then(users => {
            res.render("admin/admins", {
                title: "Users",
                users: users
            });
        })
        .catch(err => {
        console.log(err);
    })
}

// ADMIN REGISTRATION
exports.registration = (req, res, next) => {
    res.render("admin/registration", {
        title: "Registration"
    });
}

// ADMIN REGISTRATION LOGIC
exports.registrationLogic = (req, res, next) => {
    User.findOne({ email: req.body.email })
        .then(exists => {
            if (exists) {
                req.flash("error", "Email Exists");
                res.redirect("back");
            } else {
                bcrypt.genSalt(10, (err, salt) => {
                    bcrypt.hash(req.body.password, salt, (err, hash) => {
                        User.create({
                            firstName: req.body.firstName,
                            lastName: req.body.lastName,
                            email: req.body.email,
                            password: hash,
                            type: "Admin"
                        })
                            .then((user) => {
                                // SENDING EMAIL AFTER REGISTRATION
                                const mailOptions = {
                                    from: process.env.EMAIL,
                                    to: req.body.email,
                                    subject: 'Registration Confirmation',
                                    html: `Dear ${req.body.firstName}, <p>
                                    You have been registered successfully as an Admin for the House Rental Management System.</p>
                                    
                                    <p>
                                        Your password given to you is: <strong>${req.body.password}</strong>.
                                    </p>
                                    
                                    <p>
                                        You can change this password after accessing the admin dashboard.
                                    </p>
                                    
                                    <p>
                                        Sincerely, <br />
                                        HRMS Management
                                    </p>`
                                };
            
                                transporter.sendMail(mailOptions, (err, info) => {
                                    if (err) {
                                        console.log(err);
                                    } else {
                                        req.flash("success", 'Email sent:');
                                    }
                                });
                            });
                        req.flash("success","REGISTRATION SUCCESSFUL");
                        res.redirect("/admin/registration");
                    })
                })
        }
    })
}

// VIEW ADMIN INFORMATION
exports.viewAdmin = (req, res, next) => {
    User.findById(req.params.id).then(user => {
        res.render("admin/viewUser", {
            title: "Admin Profile",
            user : user
        });
    })
        .catch(err => {
            console.log(err);
    })
}

// UPDATE ADMIN INFORMATION
exports.updateAdmin = (req, res, next) => {
    if (req.body.password !== "") {
        bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(req.body.password, salt, (err, hash) => {
                User.findByIdAndUpdate({ _id: req.params.id }, {
                    firstName: req.body.firstName,
                    lastName: req.body.lastName,
                    email: req.body.email,
                    password: hash,
                    type: "Admin"
                })
                    .then((user) => {
                        req.flash("ACCOUNT INFORMATION UPDATED SUCCESSFULLY");
                        res.redirect(`/admin/user/${user._id}`);
                    })
                    .catch(err => {
                        console.log(err);
                        res.redirect("back");
                    });
            })
        })
    } else {
        User.findByIdAndUpdate({ _id: req.params.id }, {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            type: "Admin"
        })
            .then((user) => {
                console.log("ACCOUNT INFORMATION UPDATED SUCCESSFULLY");
                res.redirect(`/admin/user/${user._id}`);
            })
            .catch(err => {
                console.log(err);
        });
    }
}

// DELETE ADMIN INFORMATION
exports.deleteAdmin = (req, res, next) => {
    User.findByIdAndDelete({ _id: req.params.id })
        .then(user => {
            req.flash("success", "ADMIN INFORMATION DELETED SUCCESSFULLY");
            res.redirect("back");
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        })
}
// END OF ADMIN INFORMATION

// USERS (ADMIN)
exports.users = (req, res, next) => {
    User.find({})
        .then(users => {
            res.render("admin/users", {
                title: "Users",
                users: users
            });
        })
        .catch(err => {
        console.log(err);
    })
}

// DELETE USER INFORMATION
exports.deleteUser = (req, res, next) => {
    User.findByIdAndDelete({ _id: req.params.id })
        .then(user => {
            req.flash("success", "USER INFORMATION DELETED SUCCESSFULLY");
            res.redirect("back");
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        })
}
// END OF USER INFORMATION

// AGENTS
// GET AGENTS
exports.agents = (req, res, next) => {
    User.find({ "type": "Agent" })
        .then(agents => {
            res.render("admin/agents", {
                title: "Agents",
                agents: agents
        })
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
    })
}

// DELETE AGENT
exports.deleteAgent = (req, res, next) => {
    User.findByIdAndDelete({ _id: req.params.id })
        .then(agent => {
            House.findByIdAndDelete({postedBy: agent._id})
            .then(deletedHouse => {
                req.flash("success", "AGENT INFORMATION DELETED SUCCESSFULLY");
                res.redirect("back");
            })
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        });
}
// END OF AGENTS

// OWNERS
// GET OWNERS
exports.owners = (req, res, next) => {
    User.find({ "type": "Owner" })
        .then(owners => {
            res.render("admin/owners", {
                title: "Owners",
                owners: owners
        })
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
    })
}

// DELETE OWNERS
exports.deleteOwner = (req, res, next) => {
    User.findByIdAndDelete({ _id: req.params.id })
        .then(owner => {
            House.findByIdAndDelete({postedBy: owner._id})
            .then(deletedHouse => {
                req.flash("success", "OWNER INFORMATION DELETED SUCCESSFULLY");
                res.redirect("back");
            })
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        });
}
// END OF OWNERS

// ENQUIRIES
exports.enquiries = (req, res, next) => {
    res.render("admin/enquiries", {
        title : "Enquiries"
    })
} 

// LOGOUT LOGIC
exports.logout = (req, res) => {
    req.session.destroy();
    res.redirect("/");
}

// PROPERTY TYPE
// GET ALL PROPERTY TYPES
exports.propertyTypes = (req, res, next) => {
    PropertyType.find({})
        .then(propertyTypes => {
            res.render("admin/propertyType", {
                title: "Property Type",
                propertyTypes : propertyTypes
            });
        }) 
        .catch(err => {
            console.log(err);
        });
}

// ADD PROPERTY TYPE FORM
exports.addPropertyType = (req, res, next) => {
    res.render("admin/add-property-type", {
        title: "Add Property Type"
    })
}

// ADD PROPERTY TYPE LOGIC
exports.addPropertyTypeLogic = (req, res, next) => {
    PropertyType.create({
        type: req.body.type
    })
        .then(propertyType => {
            req.flash("success", "PROPERTY TYPE ADDED SUCCESSFULLY");
            res.redirect("/admin/property-types");
        })
        .catch(err => {
            req.flash("error", "Property Type Not Added");
            res.redirect("back");
        });
}

// VIEW SINGLE PROPERTY TYPE
exports.viewPropertyType = (req, res, next) => {
    PropertyType.findById({ _id: req.params.id })
        .then(propertyType => {
            res.render("admin/view-property-type", {
                title: "View Property Type",
                propertyType: propertyType
            });
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        });
}

// UPDATE SINGLE PROPERTY TYPE LOGIC
exports.updatePropertyType = (req, res, next) => {
    PropertyType.findByIdAndUpdate({ _id: req.params.id }, {
        type : req.body.type
    })
        .then(propertyType => {
            req.flash("success", "PROPERTY TYPE UPDATED SUCCESSFULLY");
            res.redirect("back");
        })
        .catch(err => {
            req.flash("error", "Property Type Not Updated");
            res.redirect("back");
        });
}

// DELETE SINGLE PROPERTY TYPE
exports.deletePropertyType = (req, res, next) => {
    PropertyType.findByIdAndDelete({ _id: req.params.id })
        .then(deletePropertyType => {
            req.flash("success", "PROPERTY TYPE DELETED SUCCESSFULLY");
            res.redirect("/admin/property-types");
        })
        .catch(err => {
            req.flash("error", "Property Type Not Deleted");
            res.redirect("back");
    })
}
// END OF PROPERTY TYPE

// AREA
// GET ALL AREAS
exports.areas = (req, res, next) => {
    Area.find({})
        .then(areas => {
            res.render("admin/area", {
                title: "Area",
                areas : areas
            });
        }) 
        .catch(err => {
            console.log(err);
        });
}

// ADD AREA FORM
exports.addArea = (req, res, next) => {
    res.render("admin/add-area", {
        title: "Add Property Type"
    })
}

// ADD AREA LOGIC
exports.addAreaLogic = (req, res, next) => {
    Area.create({
        name: req.body.name
    })
        .then(area => {
            req.flash("success", "AREA ADDED SUCCESSFULLY");
            res.redirect("/admin/areas");
        })
        .catch(err => {
            req.flash("error", "Error Adding Area");
            res.redirect("back");
        });
}

// VIEW SINGLE AREA
exports.viewArea = (req, res, next) => {
    Area.findById({ _id: req.params.id })
        .then(area => {
            res.render("admin/view-area", {
                title: "View Area",
                area: area
            });
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        });
}

// UPDATE SINGLE AREA LOGIC
exports.updateArea = (req, res, next) => {
    Area.findByIdAndUpdate({ _id: req.params.id }, {
        name : req.body.name
    })
        .then(area => {
            req.flash("success", "Area Updated Successfully");
            res.redirect("back");
        })
        .catch(err => {
            req.flash("error", "Area Not Deleted");
            res.redirect("back");
        });
}

// DELETE SINGLE AREA
exports.deleteArea = (req, res, next) => {
    Area.findByIdAndDelete({ _id: req.params.id })
        .then(area => {
            req.flash("success", "Area Deleted Successfully");
            res.redirect("/admin/areas");
        })
        .catch(err => {
            req.flash("error", "Area Not Deleted");
            res.redirect("back");
    })
}
// END OF AREA SECTION

// HOUSES SECTION
// GET ALL HOUSES
exports.houses = (req, res, next) => {
    House.find({})
        .then(houses => {
            User.find({})
                .then(users => {
                    res.render("admin/houses", {
                        title: "Houses",
                        houses: houses,
                        users : users
                    });    
            })
        })
        .catch(err => {
            console.log(err);
        });
}

// GET HOUSE ADD FORM
exports.addHouse = (req, res, next) => {
    PropertyType.find({})
        .then(propertyTypes => {
            Area.find({})
                .then(areas => {
                    res.render("admin/add-house", {
                        title: "Add House",
                        propertyTypes: propertyTypes,
                        areas : areas
                    });
            })
        })
        .catch(err => {
            console.log(err);
    })
}

// HOUSE ADD FORM LOGIC
exports.addHouseLogic = (req, res, next) => {
    // console.log(req.body);
    // console.log(req.file);
    // if (req.upload.fieldname !== "" && (req.upload.mimetype === "image/jpeg" || req.upload.mimetype === "image/png" || req.upload.mimetype === "image/jpg") && req.upload.size < 2000000) {
    House.create({
        name: req.body.name, // Name of the property
        address: req.body.address, // Address of the property
        type: req.body.type, // e.g., Apartment, House, Commercial, etc.
        bedrooms: req.body.bedroom, // Number of bedrooms that the property has
        bathrooms: req.body.bathroom, // Number of bathrooms that the property has
        size: req.body.size, // in square feet
        price: req.body.price, 
        status: req.body.status, // e.g., Available, Rented, Sold
        postedBy: req.session.user._id,
        area: req.body.area,
        garage: req.body.garage, // If the house has garage
        selfContain: req.body.selfContain, // If the house is self contained
        insideCompound: req.body.insideCompound, // If the house is inside a compound
        frontPicture: req.files['frontPicture'][0].buffer, // Picture of the house
        frontPictureName: req.files['frontPicture'][0].originalname, // Name of the picture
        video: req.files['video'][0].buffer,
        videoName: req.files['video'][0].originalname,
        bedroom: req.files['bedroom'][0].buffer,
        bedroomPictureName: req.files['bedroom'][0].originalname,
        insidePictureOne: req.files['insidePictureOne'][0].buffer, // Picture of inside the bathroom of the house
        insidePictureOneName: req.files['insidePictureOne'][0].filename, // Name of the bathroom picture
        // insidePictureTwo: req.upload['insidePictureTwo'][0].buffer, // Picture of inside the house
        // insidePictureTwoName: req.upload.filename, // Name of the picture
        backPicture: req.files['backPicture'][0].buffer, // Picture of the back of the house
        backPictureName: req.files['backPicture'][0].filename, // Name of the picture
        description: req.body.description// Other fields as needed
    })
        .then(house => {
            req.flash("success", "House Added Successfully");
            res.redirect("back");
        })
        .catch(err => {
            req.flash("error", "Error Adding House");
            res.redirect("back");
        });
    // } else {
    //     console.log("HOUSE PICTURES EXPECTED");
    // }
}

// VIEW SINGLE HOUSE
exports.viewHouse = (req, res, next) => {
    House.findById({ _id: req.params.id })
        .then(house => {
            PropertyType.find({})
                .then(propertyTypes => {
                    Area.find({})
                        .then(areas => {
                            User.find({})
                            .then(users => {
                                res.render("admin/view-house", {
                                    title: "View House Information",
                                    house: house,
                                    propertyTypes: propertyTypes,
                                    areas : areas,
                                    users: users
                                });    
                            })
                        
                    })
            })
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        });
}

// UPDATE SINGLE HOUSE INFORMATION
exports.updateHouseLogic = (req, res, next) => {
    if (req.file) {
        House.findByIdAndUpdate({_id : req.params.id},{
            name: req.body.name, // Name of the property
            address: req.body.address, // Address of the property
            type: req.body.type, // e.g., Apartment, House, Commercial, etc.
            bedrooms: req.body.bedroom, // Number of bedrooms that the property has
            bathrooms: req.body.bathroom, // Number of bathrooms that the property has
            size: req.body.size, // in square feet
            price: req.body.price, 
            status: req.body.status, // e.g., Available, Rented, Sold
            area: req.body.area,
            garage: req.body.garage, // If the house has garage
            selfContain: req.body.selfContain, // If the house is self contained
            insideCompound: req.body.insideCompound, // If the house is inside a compound
            frontPicture: req.files['frontPicture'][0].buffer, // Picture of the house
            frontPictureName: req.files['frontPicture'][0].originalname, // Name of the picture
            video: req.files['video'][0].buffer,
            videoName: req.files['video'][0].originalname,
            bedroom: req.files['bedroom'][0].buffer,
            bedroomPictureName: req.files['bedroom'][0].originalname,
            insidePictureOne: req.files['insidePictureOne'][0].buffer, // Picture of inside the bathroom of the house
            insidePictureOneName: req.files['insidePictureOne'][0].filename, // Name of the bathroom picture
            // insidePictureTwo: req.upload['insidePictureTwo'][0].buffer, // Picture of inside the house
            // insidePictureTwoName: req.upload.filename, // Name of the picture
            backPicture: req.files['backPicture'][0].buffer, // Picture of the back of the house
            backPictureName: req.files['backPicture'][0].filename, // Name of the picture
            description: req.body.description// Other fields as needed
        })
            .then(house => {
                req.flash("success", "House Information Updated Successfully");
                res.redirect("back");
            })
            .catch(err => {
                req.flash("error", "House Information Not Updated");
                res.redirect("back");
            });
    } else {
        House.findByIdAndUpdate({_id : req.params.id},{
        name: req.body.name, // Name of the property
        address: req.body.address, // Address of the property
        type: req.body.type, // e.g., Apartment, House, Commercial, etc.
        bedrooms: req.body.bedroom, // Number of bedrooms that the property has
        bathrooms: req.body.bathroom, // Number of bathrooms that the property has
        size: req.body.size, // in square feet
        price: req.body.price,
        status: req.body.status, // e.g., Available, Rented, Sold
        area: req.body.area,
        garage: req.body.garage, // If the house has garage
        selfContain: req.body.selfContain, // If the house is self contained
        insideCompound: req.body.insideCompound, // If the house is inside a compound
        description: req.body.description// Other fields as needed
    })
        .then(house => {
            req.flash("success", "HOUSE INFORMATION UPDATED SUCCESSFULLY");
            res.redirect("back");
        })
        .catch(err => {
            req.flash("error", "House Information Not Updated");
            res.redirect("back");
        });
    }
}

// ENQUIRIES
// GET ALL ENQUIRIES
exports.enquiries = (req, res, next) => {
    House.find({})
        .then(houses => {
            Enquiry.find({})
                .then(enquiries => {
                    User.find({})
                        .then(users => {
                            res.render("admin/enquiries", {
                                title: "Enquiries",
                                enquiries: enquiries,
                                houses: houses,
                                users: users
                            });
                    })
            })
    }).catch(err => {
        console.log(err);
        res.redirect("back");
    });
}

// VIEW SINGLE ENQUIRY
exports.singleEnquiry = (req, res, next) => {
    Enquiry.findById({ _id: req.params.id })
        .then(enquiry => {
            House.findById({ _id: enquiry.house })
                .then(house => {
                    res.render("admin/view-enquiry", {
                        title: "Single Enquiry",
                        enquiry: enquiry,
                        house: house
                    });    
            })
        })
        .catch(err => {
            console.log(err);
            res.redirect("back");
        });
}

// UPDATE ENQUIRY
exports.updateEnquiryLogic = (req, res, next) => {
    Enquiry.findByIdAndUpdate({ _id: req.params.id }, {
        enquirerName: req.body.name,
        mobileNumber: req.body.contact,
        email: req.body.email,
        message: req.body.message,
        status: req.body.status,
        remark: req.body.remark
    })
        .then(enquiry => {
            const mailOptions = {
                    from: process.env.email,
                    to: enquiry.email,
                    subject: 'Enquiry Notification',
                    html: `Dear ${enquiry.enquirerName},
                    <p>
                    This message reply is from the Owner/Agent. <br />
                    <strong>${req.body.remark}</strong>
                    </p>
                    
                    <p>
                        Sincerely, <br />
                        HRMS Management
                    </p>`
                };
            
                transporter.sendMail(mailOptions, (err, info) => {
                    if (err) {
                        req.flash("error", "Error sending Mail");
                        res.redirect("back");
                    } else {
                        req.flash("success", "Mail Sent");
                        res.redirect("back");
                        }
                    });
            req.flash("success", "Enquiry Updated Successfully");
            res.redirect("back");
        })
        .catch(err => {
            req.flash("error", "Error sending Enquiry");
            res.redirect("back");
    })
}

// DELETE ENQUIRY
exports.deleteEnquiry = (req, res, next) => {
    Enquiry.findByIdAndDelete({ _id: req.params.id })
        .then(enquiry => {
            req.flash("success", "Enquiry Deleted Successfully");
            res.redirect("back");
        })
        .catch(err => {
            req.flash("error", "Error deleting enquiry");
            res.redirect("back");
    });
}

// END OF ENQUIRIES SECTION

// DELETE SINGLE HOUSE INFORMATION
exports.deleteHouse = (req, res, next) => {
    House.findByIdAndDelete({ _id: req.params.id })
        .then(house => {
            req.flash("success", "House deleted successfully");
            res.redirect("back");
        })
        .catch(err => {
            req.flash("error", "House Not Deleted");
            res.redirect("back");
        });
}
// END OF HOUSES SECTION

// CHAT SECTION
// CHATS
exports.chats = (req, res, next) => {
    User.find({})
    .then(users => {
        if(users){
            House.find({})
            .then(houses => {
                res.render("admin/chat-users", {
                    title : "Chat Screen",
                    users: users,
                    houses: houses
                });
            })
        }
    })
    .catch(err => {
        console.log(err);
        res.redirect("back");
    })
}

// GET SELECTED USER DETAILS
exports.chatUserDetails = (req, res, next) => {
    User.find({})
    .then(users => {
        User.findById({_id : req.params.id})
        .then(selectedChatUser => {
            House.find({})
            .then(houses => {
                res.render("admin/chat-user", {
                    title : "Chat User",
                    users : users,
                    selectedChatUser : selectedChatUser,
                    houses: houses
                });
            })
        })
    })
    .catch(err => {
        console.log(err);
        res.redirect("back");
    })
}

// GET CHATS FOR SELECTED USER
// exports.singleChat = (req, res, next) => {
//     Chat.find({receiver_id : req.params.receiversID})
//     .then(chats => {
//         res.render("admin/chating", {
//             title : "Chats",
//             chats : chats
//         });
//     })
//     .catch(err => {
//         console.log(err);
//         res.redirect("back");
//     });
// }

// START CHAT
exports.chatPage = (req, res, next) => {
    User.findById({_id: req.params.receiversID})
    .then(receiver => {
        User.find({})
            .then(users => {
                Chat.find({})
                .then(chats => {
                    res.render("admin/chatting", {
                        title : "Start Chatting Page",
                        receiversID: receiver,
                        users : users,
                        chats : chats
                    });
                })
            })
    })
    .catch(err => {
        console.log(err);
        res.redirect("back");
    })
}

// ADD CHAT PAGE LOGIC
exports.addChat = (req, res, next) => {
    Chat.create({
        senderid: req.session.user._id,
        receiverid: req.params.receiversID,
        content: req.body.content
    })
    .then(chat => {
        console.log("CHAT INFORMATION ADDED SUCCESSFULLY");
        res.redirect("back");
    })
    .catch(err => {
        console.log(err);
        res.redirect("back");
    })
}

// GET CHAT FOR SELECTED USER
// exports.addChat = (req, res, next) => {
//     User.findById({_id: req.params.receiversID})
//     .then(receiver => {
//         Chat.create({
//             sender_id: req.params.sendersID,
//             receiver_id: receiver._id,
//             content: req.body.content
//         })
//         .then(chat => {
//             res.redirect("back");
//         })
//     })
//     .catch(err => {
//         console.log(err);
//         res.redirect("back");
//     })
// }

// END OF CHAT SECTION

// PAYMENTS SECTION
// GET ALL PAYMENTS
exports.payments = (req, res, next) => {
    Payment.find({}).then(payments => {
    House.find({}).then(houses => {
    User.find({}).then(users => {
    Area.find({}).then(areas => {
        res.render("admin/payments", {
            title: "Payments Made",
            payments: payments,
            houses: houses,
            users: users,
            areas: areas
        });        
    })
    })
    })
    })
        .catch(err => {
            console.log(err);
            res.redirect("back");
    })
}

// UPDATE PAYMENT INFORMATION
exports.updatePayment = (req, res, next) => {
    Payment.findByIdAndUpdate({ _id: req.params.id }, {
        nextpayment: req.body.nextpayment
    })
        .then(payment => {
            req.flash("success", "Payment information has been updated");
            res.redirect("back");
        })
        .catch(err => {
            req.flash("error", "Error Updating Payment Information");
            res.redirect("back")
        });
}

// END OF PAYMENT SECTION

// 404 PAGE
exports.error = (req, res, next) => {
    res.render("admin/404", {
        title : "House Rental Management System | Admin 404 Page"
    });
}
