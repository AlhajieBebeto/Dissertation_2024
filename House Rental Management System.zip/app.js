const express = require('express');
const mongoose = require("mongoose");
const nodemailer = require("nodemailer");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const methodOverride = require("method-override");
const Index = require("./routes/Index");
const Admin = require("./routes/Admin");
const passport = require("passport-local");
const flash = require("connect-flash");

const app = express();
require("dotenv").config();

// CONFIG
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride("_method"));
app.use(flash());

// EXPRESS SESSION
const oneDay = 1000 * 60 * 60 * 24;
app.use(session({
  secret: 'HRMS Session',
  resave: true,
  saveUninitialized: true,
  cookie: { secure: false, maxAge: oneDay }
}));

app.use((req, res, next) => {
  res.locals.user = req.session.user;
  res.locals.success = req.flash("success");
  res.locals.error = req.flash("error");
  next();
});

// MONGODB CONNECTION
mongoose.connect(process.env.MONGODB);

// ROUTES
app.use("/", Index);
app.use("/admin", Admin);

// SERVER
app.listen(process.env.PORT, () => {
    console.log(`Server Started on PORT ${process.env.PORT}`);
});
