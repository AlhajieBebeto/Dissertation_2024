window.addEventListener('load',toggleForm('credit'))
	    function toggleForm(e){
	      document.getElementById('formType').innerHTML = e === 'credit' ? `<div class="form-floating mt-3">
	        <input id="nameOnCard" type="text" class="form-control" name="name">
	        <label for="nameOnCard">Name On Card</label>
	      </div>
	      <div class="form-floating mt-3">
	        <input id="cardNumber" type="text" class="form-control" name="cardNumber" minlength="16" maxlength="16">
	        <label for="cardNumber">Card Number</label>
	      </div>
	      <div class="row g-3">
	        <div class="col">
	          <div class="form-floating mt-3">
	            <input id="expiry_mm" type="text" class="form-control" name="expiry" placeholder="mm/yy" maxlength="5">
	            <label for="expiry_mm">Expiry (mm)</label>
	          </div>
	        </div>
	        <div class="col">
	          <div class="form-floating mt-3">
	            <input id="cvv" type="text" class="form-control" name="cvv" maxlength="3">
	            <label for="cvv">CVV</label>
	          </div>
	        </div>
	      </div>` : `<div class="form-floating mt-3">
	        <input id="phone" type="text" class="form-control" name="contact">
	        <label for="phone">Phone Number</label>
	      </div>
	      <div class="form-floating mt-3">
	        <select id="paymentType" class="form-control" name="paymentType">
	          <option value="Cheque">Cheque</option>
	          <option value="Cash">Cash</option>
	        </select>
	        <label for="paymentType">Payment Type</label>
	      </div>
          <div class="form-floating mt-3">
		  <textarea id="message" class="form-control" name="message"></textarea>
		  <label for="message">Message</label>
	      </div>
          `
	    }